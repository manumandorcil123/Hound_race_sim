﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Author: Manu Dorcil
/// Date: 08 May 2025
/// Purpose: Simulates a greyhound race with 6–8 named dogs. The user selects a race type 
/// (sprint/middle distance/marathon), and the program generates multiple random scores 
/// per dog, sums them, and displays 1st–3rd place results.
/// </summary>

namespace Assignment_Greyhound
{
    internal class Program
    {
        static void Main(string[] args)
        {

            int number = 0;
            Console.WriteLine("Welcome to the annual Greyhound track meet.");
            bool restart = true;
            while (restart)
            {
                // Get number of dogs
                bool validDogCount = false;
                while (!validDogCount)
                {
                    Console.Write("How many dogs will be competing today? (6-8): ");
                    string input = Console.ReadLine();

                    if (int.TryParse(input, out number) && number >= 6 && number <= 8)
                    {
                        Console.WriteLine("Great! Prepare for the race to start!");
                        validDogCount = true;
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. There must be between 6-8 dogs competing.");
                    }
                }

                // Get dog names
                string[] dogsName = new string[number];
                for (int D = 0; D < number; D++)
                {
                    Console.Write($"Please name dog #{D + 1}: ");
                    dogsName[D] = Console.ReadLine();
                }

                {
                    // Get race type
                    int raceLength = 0;
                    string raceType = "";
                    bool validRaceType = false;

                    while (!validRaceType)
                    {
                        Console.Write("Choose the race type (sprint / middle distance / marathon): ");
                        raceType = Console.ReadLine().ToLower();

                        if (raceType == "sprint")
                        {
                            raceLength = 6;
                            validRaceType = true;
                        }
                        else if (raceType == "middle distance")
                        {
                            raceLength = 10;
                            validRaceType = true;
                        }
                        else if (raceType == "marathon")
                        {
                            raceLength = 12;
                            validRaceType = true;
                        }
                        else
                        {
                            Console.WriteLine("Invalid input. Please choose 'sprint', 'middle distance', or 'marathon'.");
                        }
                    }

                    Console.WriteLine("Starting the race! Press Enter to continue...");
                    Console.ReadLine();

                    // Set up arrays for scores and totals
                    int[,] scores = new int[number, raceLength];
                    int[] totals = new int[number];

                    Random random = new Random();

                    // Simulate the race round-by-round
                    for (int round = 0; round < raceLength; round++)
                    {
                        Console.Clear(); // Clear screen to make race readable
                        Console.WriteLine($"--- Round {round + 1} of {raceLength} ---\n");

                        for (int i = 0; i < number; i++)
                        {
                            int step = random.Next(1, 11); // 1 to 10
                            scores[i, round] = step;
                            totals[i] += step;

                            // Show dog name and progress bar
                            int stars = totals[i] / 2; // You can adjust the divisor for scaling
                            Console.Write($"{dogsName[i],-10}: ");
                            Console.WriteLine(new string('*', stars) + $" ({totals[i]})");
                        }

                        System.Threading.Thread.Sleep(1000); // Pause to simulate time between rounds
                    }



                    // Show each dog's scores
                    Console.WriteLine("Race Results:");
                    for (int i = 0; i < number; i++)
                    {
                        Console.Write($"{dogsName[i],-10}: ");
                        for (int j = 0; j < raceLength; j++)
                        {
                            Console.Write(scores[i, j] + (j < raceLength - 1 ? ", " : ""));
                        }
                        Console.WriteLine($" | Total: {totals[i]}");
                    }

                    // Determine top 3 winners
                    int[] positions = new int[number];
                    for (int i = 0; i < number; i++) positions[i] = i; // Store indices

                    // Simple selection sort based on totals
                    for (int i = 0; i < number - 1; i++)
                    {
                        int maxIndex = i;
                        for (int j = i + 1; j < number; j++)
                        {
                            if (totals[positions[j]] > totals[positions[maxIndex]])
                            {
                                maxIndex = j;
                            }
                        }
                        int temp = positions[i];
                        positions[i] = positions[maxIndex];
                        positions[maxIndex] = temp;
                    }

                    // Display winners
                    Console.WriteLine("Top 3 Winners ");
                    string[] places = { "1st", "2nd", "3rd" };
                    for (int i = 0; i < 3; i++)

                    {
                        int dogIndex = positions[i];
                        Console.WriteLine($"{places[i]} place: {dogsName[dogIndex]} (Total: {totals[dogIndex]})");
                    }
                    Console.Write("Do you want to run another race? (y/n): ");
                    string answer = Console.ReadLine().Trim().ToLower();
                    if (answer != "y")
                    {
                        restart = false;
                    }

                }
                Console.WriteLine("Thank you for attending the race!");
            }

        }
    }
}